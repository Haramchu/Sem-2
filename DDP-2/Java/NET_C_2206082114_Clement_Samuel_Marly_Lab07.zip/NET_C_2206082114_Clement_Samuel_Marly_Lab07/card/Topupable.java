package card;
// inisiasi method topup
public interface Topupable {
    void topup(double amount);
}
