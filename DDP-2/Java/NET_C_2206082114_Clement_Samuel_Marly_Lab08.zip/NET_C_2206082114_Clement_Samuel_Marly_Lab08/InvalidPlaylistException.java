// exception InvalidPlayList
public class InvalidPlaylistException extends Exception {  
    public InvalidPlaylistException(String line) {  
    super(line);  
    }  
}